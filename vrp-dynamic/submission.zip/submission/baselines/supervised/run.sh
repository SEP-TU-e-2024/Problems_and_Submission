#!/bin/bash
python solver.py --verbose --strategy supervised --model_path baselines/supervised/pretrained