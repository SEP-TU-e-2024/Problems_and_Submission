# Dummy code for testing functionality of the IOModule

from validator.validator import Validator

val = Validator()

total = 5

val.push_data(total)