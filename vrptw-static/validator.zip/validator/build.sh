# Note this script will be run in the parent directory of the validator
pip install -r ./validator/requirements.txt